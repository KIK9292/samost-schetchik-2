import React from 'react';
import {Input} from "./Input";
import {Button} from "./Button";

type CounterSettingsTypeProps={
    CallBackMenuButtonSettings:()=>void
    CallBackMaxValueInputSettings:(value:number)=>void
    CallBackMinValueInputSettings:(value:number)=>void
    ValueMax:number
    ValueMin:number
}



export const CounterSettings = (props:CounterSettingsTypeProps) => {
    const {CallBackMenuButtonSettings,CallBackMaxValueInputSettings,CallBackMinValueInputSettings,ValueMax,ValueMin}=props
    return (
        <div>
            <div>MAX</div>
            <Input callbackInput={CallBackMaxValueInputSettings} value={ValueMax}/>
            <div>MIN</div>
            <Input callbackInput={CallBackMinValueInputSettings} value={ValueMin}/>
            <Button nameButton={"SETTINGS"} callBackButton={CallBackMenuButtonSettings} disabledButton={(ValueMax<=0)||(ValueMin<0)||(ValueMax<ValueMin)||(ValueMax===ValueMin)}/>
        </div>
    );
};

