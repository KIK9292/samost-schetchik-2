import React, {ChangeEvent} from 'react';

type InuputTypeProps={
    callbackInput:(value:number)=>void
    value:number
}


export const Input:React.FC<InuputTypeProps> = ({
                                                    callbackInput,
                                                    value
                                                }) => {
    const onChangeHandler=(e:ChangeEvent<HTMLInputElement>)=>{
        callbackInput(e.currentTarget.valueAsNumber)
    }
    return (
        <div>
            <input value={value} type="number" onChange={onChangeHandler} />
        </div>
    );
};

